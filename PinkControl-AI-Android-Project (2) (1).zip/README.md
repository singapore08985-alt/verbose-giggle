# PinkControl AI - Production Android Application in Kotlin

PinkControl AI is a production-grade Android application crafted in modern **Kotlin** with **Jetpack Compose** and **Material 3**. It features an elegant pure hot-pink aesthetic (#FF2D95), full phone control via an Accessibility Service, high-fidelity voice synthesis, and multi-provider AI model orchestration.

## 🌸 Visual Theme
- **Primary Color:** `#FF2D95` (Hot Pink)
- **Secondary Color:** `#FF6BB5`
- **Background:** Soft Pink Gradient (`#FFF0F7` to `#FFE4F0`)
- **Dark Mode:** Deep Pink / Black (`#14050F` to `#220A1A`)

## 🚀 Key Features

### 1. Multi-Provider AI Engine & Key Management
- Supports **Google Gemini** (`gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-1.5-flash`), **OpenAI** (`gpt-4o`, `gpt-4o-mini`, `o1`), and **Anthropic** (`claude-3-5-sonnet`).
- Secure key storage with AndroidX **`EncryptedSharedPreferences` (AES-256 GCM)**.
- First launch onboarding and Settings screen key management.

### 2. Full Phone Control via Accessibility Service
- **Screen Reading:** Node traversal using `AccessibilityNodeInfo` to extract visible text and interactive targets.
- **Gesture Dispatching:** `dispatchGesture` for taps, swipes, and scrolling.
- **Global Actions:** Instant screenshots, home, recents, and back.
- **Automation Macros:** "Open WhatsApp and message Mom", "Scroll down", "Turn on Flashlight", "Adjust brightness".

### 3. Crystal-Clear Voice
- Google Text-to-Speech configured for high-quality natural voices.
- Speed and pitch calibration.
- Speech-to-Text with real-time recognition.

## 🛠️ How to Open and Run in Android Studio

1. Click **"Download Project ZIP"** from the top bar.
2. Extract the `.zip` archive.
3. Open **Android Studio** (Ladybug or Hedgehog recommended).
4. Select **File > Open** and choose the extracted folder.
5. Wait for Gradle sync to complete.
6. Connect your Android device (or launch an Emulator running Android 8.0+ / API 26+).
7. Press **Run (Shift + F10)**.
8. When the app opens, navigate to **Settings > Device Permissions > Accessibility Service** and toggle **PinkControl AI** to **ON**.
