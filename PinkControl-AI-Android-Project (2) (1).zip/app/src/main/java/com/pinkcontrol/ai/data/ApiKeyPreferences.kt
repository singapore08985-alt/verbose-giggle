package com.pinkcontrol.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Secure storage for API keys and user configurations using EncryptedSharedPreferences (AES256_GCM).
 */
class ApiKeyPreferences(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "pink_control_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val KEY_API_KEY = "api_key"
        private const val KEY_PROVIDER = "api_provider"
        private const val KEY_MODEL_ID = "model_id"
        private const val KEY_CUSTOM_URL = "custom_base_url"
        private const val KEY_VOICE_GENDER = "voice_gender"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_DARK_MODE = "dark_mode"
    }

    fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun getApiKey(): String = prefs.getString(KEY_API_KEY, "") ?: ""

    fun saveProvider(provider: String) {
        prefs.edit().putString(KEY_PROVIDER, provider).apply()
    }

    fun getProvider(): String = prefs.getString(KEY_PROVIDER, "gemini") ?: "gemini"

    fun saveModelId(model: String) {
        prefs.edit().putString(KEY_MODEL_ID, model).apply()
    }

    fun getModelId(): String {
        return prefs.getString(KEY_MODEL_ID, "gemini-2.5-flash") ?: "gemini-2.5-flash"
    }

    fun saveVoiceSettings(gender: String, speed: Float) {
        prefs.edit()
            .putString(KEY_VOICE_GENDER, gender)
            .putFloat(KEY_VOICE_SPEED, speed)
            .apply()
    }

    fun getVoiceSpeed(): Float = prefs.getFloat(KEY_VOICE_SPEED, 1.0f)
    fun getVoiceGender(): String = prefs.getString(KEY_VOICE_GENDER, "female") ?: "female"

    fun isApiKeyConfigured(): Boolean = getApiKey().isNotBlank()
}
