package com.pinkcontrol.ai.automation

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.Settings
import com.pinkcontrol.ai.data.api.AiClient
import com.pinkcontrol.ai.service.PinkAccessibilityService
import com.pinkcontrol.ai.service.ScreenSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Context-aware automation engine:
 * - Real-time screen context integration
 * - Offline quick match (Scroll, Screenshot, Flashlight, Brightness, Screen Reader, Targeted Clicks)
 * - LLM Agent reasoner grounded by AccessibilityNodeInfo screen hierarchy
 */
class AutomationEngine(
    private val context: Context,
    private val aiClient: AiClient
) {
    sealed class AutomationResult {
        data class Success(val message: String, val action: String? = null) : AutomationResult()
        data class Error(val error: String) : AutomationResult()
        data class DelegatedToAi(val reply: String, val screenContextUsed: Boolean = true) : AutomationResult()
    }

    /**
     * Gets live screen snapshot on demand
     */
    fun getCurrentScreenSnapshot(): ScreenSnapshot? {
        return PinkAccessibilityService.instance?.captureCurrentScreen()
            ?: PinkAccessibilityService.currentScreenSnapshot.value
    }

    suspend fun processCommand(commandText: String): AutomationResult = withContext(Dispatchers.IO) {
        val trimmed = commandText.trim().lowercase()
        val service = PinkAccessibilityService.instance

        // 1. Context-Aware Screen Reading commands
        if (trimmed.contains("what is on my screen") || trimmed.contains("read screen") || trimmed.contains("screen reader")) {
            val snapshot = getCurrentScreenSnapshot()
            return@withContext if (snapshot != null) {
                val clickableCount = snapshot.elements.count { it.isClickable }
                val summary = "Screen Reader (${snapshot.captureLatencyMs}ms): Active on ${snapshot.packageName}. ${snapshot.elements.size} elements ($clickableCount clickable). Visible text: ${snapshot.visibleTexts.take(3).joinToString(\"; \")}"
                AutomationResult.Success(summary, "screen_reading")
            } else {
                AutomationResult.Error("Accessibility Service is not active. Enable it to read screen content.")
            }
        }

        // 2. Context-Aware Targeted Click: "click [element]" or "tap [element]"
        if (trimmed.startsWith("click ") || trimmed.startsWith("tap ")) {
            val query = trimmed.removePrefix("click ").removePrefix("tap ").trim()
            val snapshot = getCurrentScreenSnapshot()
            if (snapshot != null) {
                val element = snapshot.findElementByQuery(query)
                if (element != null && service != null) {
                    service.tapAt(element.bounds.exactCenterX(), element.bounds.exactCenterY())
                    return@withContext AutomationResult.Success(
                        "Tapped '${element.displayLabel}' at (${element.bounds.centerX()}, ${element.bounds.centerY()}) via Accessibility gesture.",
                        "targeted_tap"
                    )
                }
            }
        }

        // 3. Offline Navigation & Hardware Gestures
        when {
            trimmed.contains("scroll down") || trimmed.contains("swipe down") -> {
                if (service != null) {
                    service.scrollDown()
                    AutomationResult.Success("Scrolled down smoothly.", "scroll_down")
                } else {
                    AutomationResult.Error("Accessibility service is disabled. Enable it in Settings.")
                }
            }

            trimmed.contains("scroll up") || trimmed.contains("swipe up") -> {
                if (service != null) {
                    service.scrollUp()
                    AutomationResult.Success("Scrolled up.", "scroll_up")
                } else {
                    AutomationResult.Error("Accessibility service is disabled.")
                }
            }

            trimmed.contains("take screenshot") || trimmed.contains("screenshot") -> {
                if (service != null) {
                    service.takeScreenshotAction()
                    AutomationResult.Success("Screenshot captured!", "screenshot")
                } else {
                    AutomationResult.Error("Accessibility service needed for screenshot.")
                }
            }

            trimmed.contains("turn on flashlight") || trimmed.contains("flashlight on") -> {
                toggleFlashlight(true)
                AutomationResult.Success("Flashlight turned ON.", "flashlight_on")
            }

            trimmed.contains("turn off flashlight") || trimmed.contains("flashlight off") -> {
                toggleFlashlight(false)
                AutomationResult.Success("Flashlight turned OFF.", "flashlight_off")
            }

            trimmed.contains("open whatsapp") -> {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    if (trimmed.contains("message")) {
                        handleWhatsAppMessageMacro(trimmed)
                    }
                    AutomationResult.Success("Opened WhatsApp.", "open_whatsapp")
                } else {
                    AutomationResult.Error("WhatsApp is not installed on this device.")
                }
            }

            trimmed.contains("open settings") -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                AutomationResult.Success("Opened Android Settings.", "open_settings")
            }

            // 4. Delegate to AI Model (Gemini / OpenAI / Claude) with Real-Time Screen Context
            else -> {
                val snapshot = getCurrentScreenSnapshot()
                val screenContext = snapshot?.toAiContextString() ?: "Screen content unavailable"
                
                val prompt = """
                    You are PinkControl AI, an intelligent Android phone controller with Accessibility permissions.
                    The user gave this voice command: "$commandText"
                    
                    $screenContext
                    
                    Determine the exact action to take or provide a concise, direct answer based on what is visible on screen.
                """.trimIndent()

                try {
                    val aiReply = aiClient.generateReply(prompt)
                    AutomationResult.DelegatedToAi(aiReply, screenContextUsed = snapshot != null)
                } catch (e: Exception) {
                    AutomationResult.Error("AI Error: ${e.localizedMessage}")
                }
            }
        }
    }

    private fun toggleFlashlight(status: Boolean) {
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, status)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleWhatsAppMessageMacro(command: String) {
        val service = PinkAccessibilityService.instance ?: return
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            service.clickTextOnScreen("Mom")
        }, 1200)
    }
}
