package com.pinkcontrol.ai.service

import android.graphics.Rect

/**
 * Encapsulates real-time captured screen content for context-aware AI automation.
 */
data class ScreenElement(
    val id: String?,
    val text: String?,
    val contentDescription: String?,
    val className: String?,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val isChecked: Boolean,
    val bounds: Rect
) {
    val displayLabel: String
        get() = text?.takeIf { it.isNotBlank() }
            ?: contentDescription?.takeIf { it.isNotBlank() }
            ?: id?.substringAfterLast('/')
            ?: "unnamed_view"
}

data class ScreenSnapshot(
    val packageName: String,
    val windowTitle: String,
    val elements: List<ScreenElement>,
    val visibleTexts: List<String>,
    val timestamp: Long = System.currentTimeMillis(),
    val captureLatencyMs: Long = 0
) {
    /**
     * Compact, token-efficient representation formatted for LLM system/user prompts
     */
    fun toAiContextString(): String {
        val sb = StringBuilder()
        sb.append("=== ACTIVE SCREEN CONTEXT ===\n")
        sb.append("Package: $packageName\n")
        sb.append("Window: $windowTitle\n")
        sb.append("Interactive Elements (${elements.size}):\n")
        elements.take(35).forEach { el ->
            val type = when {
                el.isEditable -> "Input"
                el.isClickable -> "Button"
                el.isScrollable -> "ScrollArea"
                else -> "Text"
            }
            sb.append("- [$type] \"${el.displayLabel}\" (clickable=${el.isClickable}, bounds=[${el.bounds.left},${el.bounds.top},${el.bounds.right},${el.bounds.bottom}])\n")
        }
        if (visibleTexts.isNotEmpty()) {
            sb.append("\nProminent Texts:\n")
            visibleTexts.take(8).forEach { sb.append("• \"$it\"\n") }
        }
        sb.append("=============================")
        return sb.toString()
    }

    fun findElementByQuery(query: String): ScreenElement? {
        val q = query.trim().lowercase()
        return elements.firstOrNull { el ->
            el.text?.lowercase()?.contains(q) == true ||
            el.contentDescription?.lowercase()?.contains(q) == true ||
            el.id?.lowercase()?.contains(q) == true
        }
    }
}
