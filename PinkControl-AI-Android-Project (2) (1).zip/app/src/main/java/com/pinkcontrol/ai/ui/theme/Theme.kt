package com.pinkcontrol.ai.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightPinkColorScheme = lightColorScheme(
    primary = PinkPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD8E7),
    onPrimaryContainer = Color(0xFF3D0020),
    secondary = PinkSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFEBF3),
    onSecondaryContainer = Color(0xFF3E0025),
    background = PinkBackgroundLight,
    onBackground = PinkTextPrimaryLight,
    surface = PinkSurfaceLight,
    onSurface = PinkTextPrimaryLight,
    surfaceVariant = PinkSurfaceSubtle,
    onSurfaceVariant = PinkTextSecondaryLight,
    outline = Color(0xFFFFB3D5)
)

private val DarkPinkColorScheme = darkColorScheme(
    primary = PinkPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF5D0032),
    onPrimaryContainer = Color(0xFFFFD8E7),
    secondary = PinkSecondary,
    onSecondary = Color(0xFF330018),
    secondaryContainer = Color(0xFF450D2C),
    onSecondaryContainer = Color(0xFFFFD8E7),
    background = PinkBackgroundDark,
    onBackground = PinkTextPrimaryDark,
    surface = PinkSurfaceDark,
    onSurface = PinkTextPrimaryDark,
    surfaceVariant = PinkSurfaceDarkElevated,
    onSurfaceVariant = PinkTextSecondaryDark,
    outline = Color(0xFF6B2247)
)

@Composable
fun PinkControlTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkPinkColorScheme else LightPinkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
