package com.pinkcontrol.ai.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Pure Elegant Hot Pink Palette
val PinkPrimary = Color(0xFFFF2D95)       // Hot Pink (#FF2D95)
val PinkSecondary = Color(0xFFFF6BB5)     // Soft Pink Accent (#FF6BB5)
val PinkTertiary = Color(0xFFFF85C2)      // Pastel Glow
val PinkPrimaryDark = Color(0xFFD6006D)   // Deep Vibrant Pink

// Backgrounds
val PinkBackgroundLight = Color(0xFFFFF0F7) // Soft pink gradient start
val PinkBackgroundEnd = Color(0xFFFFE4F0)   // Soft pink gradient end
val PinkSurfaceLight = Color(0xFFFFFFFF)
val PinkSurfaceSubtle = Color(0xFFFFF5FA)

// Dark Mode Palette
val PinkBackgroundDark = Color(0xFF14050F) // Deep black-pink
val PinkSurfaceDark = Color(0xFF220A1A)    // Elevated surface
val PinkSurfaceDarkElevated = Color(0xFF301025)
val PinkCardDark = Color(0xFF2B0C21)

// Accents & Texts
val PinkTextPrimaryLight = Color(0xFF2B081A)
val PinkTextSecondaryLight = Color(0xFF784561)
val PinkTextPrimaryDark = Color(0xFFFFF0F6)
val PinkTextSecondaryDark = Color(0xFFD4A3BD)

val PinkGlow = Color(0x66FF2D95)

// Gradient Brushes
val PinkGradientBrushLight = Brush.verticalGradient(
    colors = listOf(PinkBackgroundLight, PinkBackgroundEnd)
)

val PinkGradientBrushDark = Brush.verticalGradient(
    colors = listOf(PinkBackgroundDark, Color(0xFF1F0818))
)

val PinkButtonGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFF2D95), Color(0xFFFF52A8))
)
