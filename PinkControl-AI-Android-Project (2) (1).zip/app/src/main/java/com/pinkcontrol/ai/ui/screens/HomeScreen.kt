package com.pinkcontrol.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pinkcontrol.ai.automation.AutomationEngine
import com.pinkcontrol.ai.ui.components.PinkGlowingMicButton
import com.pinkcontrol.ai.ui.components.PinkStatusBadge
import com.pinkcontrol.ai.ui.theme.PinkPrimary
import com.pinkcontrol.ai.ui.theme.PinkSecondary
import com.pinkcontrol.ai.voice.VoiceManager
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    activeModel: String,
    isAccessibilityActive: Boolean,
    voiceManager: VoiceManager,
    automationEngine: AutomationEngine,
    onOpenAccessibilitySettings: () -> Unit,
    onNavigateToChat: () -> Unit
) {
    val isListening by voiceManager.isListening.collectAsState()
    val recognizedText by voiceManager.recognizedText.collectAsState()
    val scope = rememberCoroutineScope()
    var executionStatus by remember { mutableStateOf<String?>(null) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Top Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PinkControl AI",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = PinkPrimary
                )
                Text(
                    text = "Voice & Accessibility Controller",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }

            PinkStatusBadge(
                title = if (isAccessibilityActive) "Accessibility ON" else "Accessibility OFF",
                isActive = isAccessibilityActive,
                onClick = onOpenAccessibilitySettings
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Active Model Pill
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = PinkPrimary.copy(alpha = 0.08f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.SmartToy, contentDescription = null, tint = PinkPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("ACTIVE ENGINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                    Text(activeModel, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(36.dp))

        // Big Glowing Mic Button
        PinkGlowingMicButton(
            isListening = isListening,
            onClick = {
                if (isListening) {
                    voiceManager.stopListening()
                } else {
                    executionStatus = "Listening for your voice command..."
                    voiceManager.startListening { spoken ->
                        executionStatus = "Executing: \"$spoken\""
                        scope.launch {
                            val result = automationEngine.processCommand(spoken)
                            executionStatus = when (result) {
                                is AutomationEngine.AutomationResult.Success -> {
                                    voiceManager.speak(result.message)
                                    result.message
                                }
                                is AutomationEngine.AutomationResult.DelegatedToAi -> {
                                    voiceManager.speak(result.reply)
                                    result.reply
                                }
                                is AutomationEngine.AutomationResult.Error -> {
                                    voiceManager.speak("Error: ${result.error}")
                                    "Error: ${result.error}"
                                }
                            }
                        }
                    }
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = if (isListening) "Listening... Tap to stop" else "Tap to Speak",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = if (isListening) PinkPrimary else Color.Gray
        )

        // Live recognized speech preview
        if (recognizedText.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = recognizedText,
                    modifier = Modifier.padding(14.dp),
                    fontSize = 14.sp,
                    color = Color.DarkGray
                )
            }
        }

        if (executionStatus != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = executionStatus ?: "",
                fontSize = 13.sp,
                color = PinkPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Quick Action Shortcuts
        Text(
            text = "Quick Phone Actions",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionItem(
                title = "Scroll Down",
                icon = Icons.Default.ArrowDownward,
                modifier = Modifier.weight(1f)
            ) {
                scope.launch { automationEngine.processCommand("scroll down") }
            }
            QuickActionItem(
                title = "Screenshot",
                icon = Icons.Default.CameraAlt,
                modifier = Modifier.weight(1f)
            ) {
                scope.launch { automationEngine.processCommand("take screenshot") }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionItem(
                title = "Flashlight",
                icon = Icons.Default.FlashlightOn,
                modifier = Modifier.weight(1f)
            ) {
                scope.launch { automationEngine.processCommand("turn on flashlight") }
            }
            QuickActionItem(
                title = "Open WhatsApp",
                icon = Icons.Default.Chat,
                modifier = Modifier.weight(1f)
            ) {
                scope.launch { automationEngine.processCommand("open whatsapp") }
            }
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PinkPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
