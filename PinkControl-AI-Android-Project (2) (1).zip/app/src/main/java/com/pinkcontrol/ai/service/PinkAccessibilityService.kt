package com.pinkcontrol.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * PinkControl Accessibility Service:
 * - High-performance real-time screen reading with low-latency node traversal
 * - Debounced event listener to prevent UI lag/battery drain
 * - Structured ScreenSnapshot with interactive elements & bounds
 * - Dispatches tap, swipe, long-press, and scroll gestures
 * - Global actions (screenshots, home, back)
 */
class PinkAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "PinkAccessibility"
        private const val MAX_DEPTH = 16
        private const val MAX_NODES = 120
        private const val DEBOUNCE_INTERVAL_MS = 250L

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning = _isServiceRunning.asStateFlow()

        private val _currentScreenText = MutableStateFlow("")
        val currentScreenText = _currentScreenText.asStateFlow()

        private val _currentScreenSnapshot = MutableStateFlow<ScreenSnapshot?>(null)
        val currentScreenSnapshot = _currentScreenSnapshot.asStateFlow()

        var instance: PinkAccessibilityService? = null
            private set
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var screenDebounceJob: Job? = null
    private var lastCaptureTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceRunning.value = true
        Log.i(TAG, "PinkControl AI Accessibility Service Connected with Real-Time Screen Reader!")
        scheduleScreenCapture(forceImmediate = true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Filter high-priority content/window change events
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                scheduleScreenCapture(forceImmediate = false)
            }
        }
    }

    /**
     * Debounces screen reading capture to avoid performance hits during rapid scrolling
     */
    private fun scheduleScreenCapture(forceImmediate: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        if (forceImmediate || now - lastCaptureTime > DEBOUNCE_INTERVAL_MS) {
            screenDebounceJob?.cancel()
            screenDebounceJob = serviceScope.launch {
                if (!forceImmediate) delay(DEBOUNCE_INTERVAL_MS)
                captureScreenInternal()
                lastCaptureTime = SystemClock.uptimeMillis()
            }
        }
    }

    /**
     * Traverses AccessibilityNodeInfo safely with depth & count limits
     */
    @Synchronized
    fun captureCurrentScreen(): ScreenSnapshot {
        return captureScreenInternal()
    }

    private fun captureScreenInternal(): ScreenSnapshot {
        val startNs = System.nanoTime()
        val root = rootInActiveWindow
        val elements = mutableListOf<ScreenElement>()
        val visibleTexts = mutableListOf<String>()
        val packageName = root?.packageName?.toString() ?: "unknown"
        val windowTitle = root?.className?.toString() ?: "Active Window"

        if (root != null) {
            traverseNode(root, 0, elements, visibleTexts)
        }

        val latencyMs = (System.nanoTime() - startNs) / 1_000_000
        val snapshot = ScreenSnapshot(
            packageName = packageName,
            windowTitle = windowTitle,
            elements = elements,
            visibleTexts = visibleTexts,
            captureLatencyMs = latencyMs
        )

        _currentScreenSnapshot.value = snapshot
        _currentScreenText.value = visibleTexts.joinToString("\n")
        return snapshot
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        elements: MutableList<ScreenElement>,
        visibleTexts: MutableList<String>
    ) {
        if (depth > MAX_DEPTH || elements.size >= MAX_NODES) return

        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        val isClickable = node.isClickable
        val isEditable = node.isEditable
        val isScrollable = node.isScrollable

        if (!text.isNullOrBlank() && !visibleTexts.contains(text)) {
            visibleTexts.add(text)
        } else if (!desc.isNullOrBlank() && !visibleTexts.contains(desc)) {
            visibleTexts.add(desc)
        }

        // Only register elements that convey semantic value or interactability
        if (isClickable || isEditable || isScrollable || !text.isNullOrBlank() || !desc.isNullOrBlank()) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            elements.add(
                ScreenElement(
                    id = node.viewIdResourceName,
                    text = text,
                    contentDescription = desc,
                    className = node.className?.toString(),
                    isClickable = isClickable,
                    isEditable = isEditable,
                    isScrollable = isScrollable,
                    isChecked = node.isChecked,
                    bounds = bounds
                )
            )
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, depth + 1, elements, visibleTexts)
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "PinkAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        instance = null
        _isServiceRunning.value = false
    }

    /**
     * Dispatches a tap gesture at coordinate (x, y)
     */
    fun tapAt(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    /**
     * Dispatches a swipe gesture (e.g. scroll down or up)
     */
    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300, callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    fun scrollDown() {
        val metrics = resources.displayMetrics
        val centerX = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.75f
        val endY = metrics.heightPixels * 0.25f
        swipe(centerX, startY, centerX, endY, 350)
    }

    fun scrollUp() {
        val metrics = resources.displayMetrics
        val centerX = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.25f
        val endY = metrics.heightPixels * 0.75f
        swipe(centerX, startY, centerX, endY, 350)
    }

    fun takeScreenshotAction() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    /**
     * Targeted click on an element located by text query
     */
    fun clickTextOnScreen(targetText: String): Boolean {
        val snapshot = captureCurrentScreen()
        val target = snapshot.findElementByQuery(targetText)
        if (target != null && target.bounds.width() > 0) {
            tapAt(target.bounds.exactCenterX(), target.bounds.exactCenterY())
            return true
        }
        return false
    }
}
