package com.pinkcontrol.ai.data.api

import com.pinkcontrol.ai.data.ApiKeyPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Universal AI client executing requests to Google Gemini, OpenAI, or Anthropic.
 */
class AiClient(private val prefs: ApiKeyPreferences) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateReply(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = prefs.getApiKey()
        if (apiKey.isBlank()) {
            return@withContext "PinkControl Alert: Please configure your API key in Settings first."
        }

        val provider = prefs.getProvider()
        val model = prefs.getModelId()

        when (provider.lowercase()) {
            "gemini" -> callGemini(apiKey, model, prompt)
            "openai" -> callOpenAi(apiKey, model, prompt)
            "anthropic" -> callAnthropic(apiKey, model, prompt)
            else -> callOpenAi(apiKey, model, prompt) // default fallback
        }
    }

    private fun callGemini(apiKey: String, model: String, prompt: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    })
                })
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("Gemini API Error (${response.code}): ${response.body?.string()}")
            }
            val resJson = JSONObject(response.body?.string() ?: "{}")
            return resJson.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text") ?: "No response from Gemini."
        }
    }

    private fun callOpenAi(apiKey: String, model: String, prompt: String): String {
        val url = "https://api.openai.com/v1/chat/completions"
        val payload = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
        }

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $apiKey")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("OpenAI API Error (${response.code}): ${response.body?.string()}")
            }
            val resJson = JSONObject(response.body?.string() ?: "{}")
            return resJson.optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content") ?: "No response from OpenAI."
        }
    }

    private fun callAnthropic(apiKey: String, model: String, prompt: String): String {
        val url = "https://api.anthropic.com/v1/messages"
        val payload = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1024)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
        }

        val request = Request.Builder()
            .url(url)
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("Anthropic API Error (${response.code}): ${response.body?.string()}")
            }
            val resJson = JSONObject(response.body?.string() ?: "{}")
            return resJson.optJSONArray("content")
                ?.optJSONObject(0)
                ?.optString("text") ?: "No response from Claude."
        }
    }
}
