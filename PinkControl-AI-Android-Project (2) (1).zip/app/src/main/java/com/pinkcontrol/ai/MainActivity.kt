package com.pinkcontrol.ai

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.pinkcontrol.ai.automation.AutomationEngine
import com.pinkcontrol.ai.data.ApiKeyPreferences
import com.pinkcontrol.ai.data.api.AiClient
import com.pinkcontrol.ai.service.PinkAccessibilityService
import com.pinkcontrol.ai.ui.screens.*
import com.pinkcontrol.ai.ui.theme.PinkBackgroundLight
import com.pinkcontrol.ai.ui.theme.PinkControlTheme
import com.pinkcontrol.ai.ui.theme.PinkPrimary
import com.pinkcontrol.ai.voice.VoiceManager

class MainActivity : ComponentActivity() {

    private lateinit var prefs: ApiKeyPreferences
    private lateinit var aiClient: AiClient
    private lateinit var voiceManager: VoiceManager
    private lateinit var automationEngine: AutomationEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = ApiKeyPreferences(this)
        aiClient = AiClient(prefs)
        voiceManager = VoiceManager(this)
        automationEngine = AutomationEngine(this, aiClient)

        setContent {
            var isDarkMode by remember { mutableStateOf(false) }
            var currentScreen by remember { mutableStateOf("home") }
            val isAccessibilityActive by PinkAccessibilityService.isServiceRunning.collectAsState()

            // Microphone permission launcher
            val micPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { isGranted ->
                if (isGranted) {
                    // Mic granted
                }
            }

            LaunchedEffect(Unit) {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }

            PinkControlTheme(darkTheme = isDarkMode) {
                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = if (isDarkMode) Color(0xFF1F0818) else Color(0xFFFFF0F7),
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == "home",
                                onClick = { currentScreen = "home" },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = PinkPrimary,
                                    indicatorColor = PinkPrimary
                                )
                            )
                            NavigationBarItem(
                                selected = currentScreen == "chat",
                                onClick = { currentScreen = "chat" },
                                icon = { Icon(Icons.Default.ChatBubble, contentDescription = "Chat") },
                                label = { Text("AI Chat") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = PinkPrimary,
                                    indicatorColor = PinkPrimary
                                )
                            )
                            NavigationBarItem(
                                selected = currentScreen == "automation",
                                onClick = { currentScreen = "automation" },
                                icon = { Icon(Icons.Default.AutoMode, contentDescription = "Automations") },
                                label = { Text("Actions") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = PinkPrimary,
                                    indicatorColor = PinkPrimary
                                )
                            )
                            NavigationBarItem(
                                selected = currentScreen == "settings",
                                onClick = { currentScreen = "settings" },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = PinkPrimary,
                                    indicatorColor = PinkPrimary
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            "home" -> HomeScreen(
                                activeModel = prefs.getModelId(),
                                isAccessibilityActive = isAccessibilityActive,
                                voiceManager = voiceManager,
                                automationEngine = automationEngine,
                                onOpenAccessibilitySettings = {
                                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                },
                                onNavigateToChat = { currentScreen = "chat" }
                            )
                            "chat" -> ChatScreen(
                                aiClient = aiClient,
                                voiceManager = voiceManager,
                                activeModel = prefs.getModelId()
                            )
                            "automation" -> AutomationScreen(
                                automationEngine = automationEngine
                            )
                            "settings" -> SettingsScreen(
                                prefs = prefs,
                                isDarkMode = isDarkMode,
                                onToggleDarkMode = { isDarkMode = it },
                                voiceManager = voiceManager
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.release()
    }
}
