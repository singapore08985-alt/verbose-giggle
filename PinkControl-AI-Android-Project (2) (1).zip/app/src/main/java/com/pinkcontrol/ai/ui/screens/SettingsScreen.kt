package com.pinkcontrol.ai.ui.screens

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pinkcontrol.ai.data.ApiKeyPreferences
import com.pinkcontrol.ai.ui.theme.PinkPrimary
import com.pinkcontrol.ai.ui.theme.PinkSecondary
import com.pinkcontrol.ai.voice.VoiceManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefs: ApiKeyPreferences,
    isDarkMode: Boolean,
    onToggleDarkMode: (Boolean) -> Unit,
    voiceManager: VoiceManager
) {
    val context = LocalContext.current
    var selectedProvider by remember { mutableStateOf(prefs.getProvider()) }
    var selectedModel by remember { mutableStateOf(prefs.getModelId()) }
    var apiKeyInput by remember { mutableStateOf(prefs.getApiKey()) }
    var saveFeedback by remember { mutableStateOf<String?>(null) }
    var voiceSpeed by remember { mutableStateOf(prefs.getVoiceSpeed()) }
    var isProviderDropdownOpen by remember { mutableStateOf(false) }
    var isModelDropdownOpen by remember { mutableStateOf(false) }

    val providers = listOf("gemini", "openai", "anthropic", "custom")
    val modelsMap = mapOf(
        "gemini" to listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-1.5-flash", "gemini-1.5-pro"),
        "openai" to listOf("gpt-4o", "gpt-4o-mini", "o1", "o3-mini"),
        "anthropic" to listOf("claude-3-5-sonnet", "claude-3-5-haiku", "claude-3-opus"),
        "custom" to listOf("custom-model")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "Settings & API Keys",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = PinkPrimary
        )
        Text(
            text = "Configure your AI engine and phone control parameters",
            fontSize = 13.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. API Key & Provider Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("AI Provider & Key Management", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))

                // Provider Dropdown
                ExposedDropdownMenuBox(
                    expanded = isProviderDropdownOpen,
                    onExpandedChange = { isProviderDropdownOpen = !isProviderDropdownOpen }
                ) {
                    OutlinedTextField(
                        value = selectedProvider.uppercase(),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Provider") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isProviderDropdownOpen) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isProviderDropdownOpen,
                        onDismissRequest = { isProviderDropdownOpen = false }
                    ) {
                        providers.forEach { provider ->
                            DropdownMenuItem(
                                text = { Text(provider.uppercase()) },
                                onClick = {
                                    selectedProvider = provider
                                    selectedModel = modelsMap[provider]?.first() ?: ""
                                    isProviderDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Model Dropdown
                ExposedDropdownMenuBox(
                    expanded = isModelDropdownOpen,
                    onExpandedChange = { isModelDropdownOpen = !isModelDropdownOpen }
                ) {
                    OutlinedTextField(
                        value = selectedModel,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Active Model") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isModelDropdownOpen) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isModelDropdownOpen,
                        onDismissRequest = { isModelDropdownOpen = false }
                    ) {
                        (modelsMap[selectedProvider] ?: emptyList()).forEach { model ->
                            DropdownMenuItem(
                                text = { Text(model) },
                                onClick = {
                                    selectedModel = model
                                    isModelDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // API Key Text Field with Paste Button
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    label = { Text("API Key") },
                    placeholder = { Text("Paste your API Key here") },
                    trailingIcon = {
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clipData = clipboard.primaryClip
                            if (clipData != null && clipData.itemCount > 0) {
                                apiKeyInput = clipData.getItemAt(0).text.toString()
                            }
                        }) {
                            Icon(Icons.Default.ContentPaste, contentDescription = "Paste", tint = PinkPrimary)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        prefs.saveProvider(selectedProvider)
                        prefs.saveModelId(selectedModel)
                        prefs.saveApiKey(apiKeyInput)
                        saveFeedback = "Saved securely using EncryptedSharedPreferences!"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Key Securely (AES-256 GCM)")
                }

                if (saveFeedback != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        saveFeedback ?: "",
                        fontSize = 12.sp,
                        color = PinkPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Crystal-Clear Voice Settings
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Voice & Speech Engine", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Speaking Speed: ${String.format("%.1f", voiceSpeed)}x", fontSize = 13.sp)
                Slider(
                    value = voiceSpeed,
                    onValueChange = {
                        voiceSpeed = it
                        voiceManager.setSpeechRate(it)
                        prefs.saveVoiceSettings("female", it)
                    },
                    valueRange = 0.7f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = PinkPrimary, activeTrackColor = PinkSecondary)
                )

                Button(
                    onClick = {
                        voiceManager.speak("Hello! PinkControl AI voice engine is crystal clear and ready.")
                    },
                    colors = ButtonDefaults.outlinedButtonColors(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = PinkPrimary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Premium Voice", color = PinkPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. System Permissions Manager
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Device Permissions", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                PermissionRow("Accessibility Service", "Enables gestures and screen reading") {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                PermissionRow("Microphone Access", "Enables crystal-clear voice commands") {
                    // Handled via runtime dialog
                }
                PermissionRow("Display Over Other Apps", "Floating pink voice widget") {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                }
            }
        }
    }
}

@Composable
fun PermissionRow(title: String, subtitle: String, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = Color.Gray)
        }
        TextButton(onClick = onOpenSettings) {
            Text("Configure", color = PinkPrimary, fontSize = 12.sp)
        }
    }
}
